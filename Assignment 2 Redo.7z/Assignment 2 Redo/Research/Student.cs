﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 *  Student Class - Inherits Properties from the "Researcher" Class but adds features
 *                  meant for Students (A Sub-Class of Researcher)
 *  Author(s) So Far - Harrison Adams, XXX
 *  Completion Date - N/A
 */

namespace Assignment_2_Redo.Research
{
    class Student
    {
        //Variables
        private string Degree;  //The Degree a Student Has

        //Gets All the Data from Researcher

        //Gets User Input for Degree

        //Stores in Database
         
    }
}
