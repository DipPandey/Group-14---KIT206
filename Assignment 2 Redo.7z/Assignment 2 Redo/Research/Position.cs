﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 *  Position Class -    Has a position that the Researcher was in sometime, along with
 *                      their Starting Date of said Position, Position Level, and the
 *                      End Date of Position if applicable
 *  Author(s) So Far -  Harrison Adams, XXX
 *  Completion Date -   N/A
 */

namespace Assignment_2_Redo.Research
{
    class Position
    {
        //Variables (Change to Proper Format Later)
        private string level;   //Change String Later
        private string start;   //Start Date of Job
        private string end;     //End Date of Job

        /* Getting User Input
         *  Level has to be an ENUM using Researcher's "EmploymentLevel"
         *  Start has to be Less than End Date and vice versa
         *  All have to be in proper format
         */

        //Format it using "Title" or "ToTitle" Method

        //Stores to Database

    }

    /*
     *  Title - 
     *  @p1 - 
     *  Output - 
     */
    public void Title()
    {

    }

    /*
     * ToTitle - 
     * @p1 - 
     * Output - 
     */
    public void ToTitle(string EmployLevel)
    {

    }


}
        

